package com.le.xiong.live.video.util;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class ConfigUtil {

    private static String[] getConfigs(Context context){
        try {
            InputStream is=context.getAssets().open("config.so");
            ByteArrayOutputStream baos=new ByteArrayOutputStream();
            byte[] bytes=new byte[1024];
            int len;
            while ((len=is.read(bytes))>0){
                baos.write(bytes,0,len);
            }
            return baos.toString().split("\n");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getUrl(Context context){
        String[] configs=getConfigs(context);
        if (configs==null){
            return null;
        }
        return AESUtils.AES_Decrypt(configs[0].trim(),"xiaochenxiugai","CBC");
    }

    public static String getHost(Context context){
        String[] configs=getConfigs(context);
        if (configs==null){
            return null;
        }
        return AESUtils.AES_Decrypt(configs[1].trim(),"xiaochenxiugai","CBC");
    }

    public static String getIndexImage(Context context){
        String[] configs=getConfigs(context);
        if (configs==null){
            return null;
        }
        return AESUtils.AES_Decrypt(configs[2].trim(),"xiaochenxiugai","CBC");
    }

    public static String getU(Context context){
        String[] configs=getConfigs(context);
        if (configs==null){
            return null;
        }
        return AESUtils.AES_Decrypt(configs[3].trim(),"xiaochenxiugai","CBC");
    }
}
