package com.le.xiong.live.video;

import android.app.Application;
import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class App extends Application {

    private String user;
    private String code;

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getUser() {
        return user;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        try{
            System.loadLibrary("xc");
        } catch (UnsatisfiedLinkError e) {
            e.printStackTrace();
        }
    }
}
