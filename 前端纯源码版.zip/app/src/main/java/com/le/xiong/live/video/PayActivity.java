package com.le.xiong.live.video;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import com.le.xiong.live.video.util.ConfigUtil;
import com.le.xiong.live.video.util.PayUtil;
import com.le.xiong.live.video.util.SystemUtils;

public class PayActivity extends AppCompatActivity {

    private String data=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay);

        SystemUtils.setStatusBarColor(this, Color.parseColor("#FFFFFF"));
        SystemUtils.setNavBarBackground(this,"#FFFFFF");

        final String host= ConfigUtil.getHost(this);
        //Toast.makeText(this, "获取抖音账号", Toast.LENGTH_SHORT).show();
        PayUtil.showLoad(this);

        new Thread(new Runnable() {
            @Override
            public void run() {
                assert host != null;
                if (!host.contains("http://")){
                    data = SystemUtils.post("http://"+host.trim()+"/public/index.php?s=index/api/getInfo","");
                    if (data!=null){
                        PayActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //Toast.makeText(PayActivity.this, "获取到抖音信息:"+data, Toast.LENGTH_SHORT).show();
                                PayUtil.init(PayActivity.this,R.id.pay_box,data,host);
                            }
                        });
                    } else {
                        PayActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(PayActivity.this, "网络链接错误", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        });
                    }
                }else {
                    PayActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //Toast.makeText(PayActivity.this, "获取到抖音信息:"+data, Toast.LENGTH_SHORT).show();
                            PayUtil.init(PayActivity.this,R.id.pay_box,data,host);
                        }
                    });
                }

            }
        }).start();
    }
}
