package com.le.xiong.live.video.util;

import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.text.TextUtils;

import androidx.core.app.NotificationManagerCompat;

import com.le.xiong.live.video.service.MsgService;

import java.util.Set;

import static android.content.Context.ACTIVITY_SERVICE;

public class MsgSrviceUtil {

    public static void gotoNotificationAccessSetting(Context paramContext) {
        Intent var2;
        boolean var3;
        try {
            var2 = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            paramContext.startActivity(var2);
        } catch (ActivityNotFoundException var6) {
            try {
                var2 = new Intent();
                ComponentName var4 = new ComponentName("com.android.settings", "com.android.settings.Settings$NotificationAccessSettingsActivity");
                var2.setComponent(var4);
                var2.putExtra(":settings:show_fragment", "NotificationAccessSettings");
                paramContext.startActivity(var2);
            } catch (Exception var5) {
                var5.printStackTrace();
                var3 = false;
                return;
            }
            var3 = true;
            return;
        }
        var3 = true;
    }

    public static boolean isEnabled(Context context) {
        String pkgName = context.getPackageName();
        final String flat = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        if (!TextUtils.isEmpty(flat)) {
            final String[] names = flat.split(":");
            for (String name : names) {
                final ComponentName cn = ComponentName.unflattenFromString(name);
                if (cn != null) {
                    if (TextUtils.equals(pkgName, cn.getPackageName())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static boolean isRunService(Context context,String serviceName) {
        ActivityManager manager = (ActivityManager) context.getSystemService(ACTIVITY_SERVICE);
        assert manager != null;
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceName.equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    private static boolean is(Context context){
        Set<String> packs= NotificationManagerCompat.getEnabledListenerPackages(context);
        if (packs.contains(context.getPackageName())){
            return true;
        }
        return false;
    }

    public static boolean start(Context context){
        try {
            if (!isEnabled(context)) {
                gotoNotificationAccessSetting(context);
                return false;
            }else {
                if (is(context)){
                    re(context);
                }
                context.startService(new Intent(context, MsgService.class));
                return true;
            }
        }catch (Exception e){
            SystemUtils.writeLog("启动服务："+e.getMessage());
        }
        return false;
    }



    public static void re(Context context){
        PackageManager pm = context.getPackageManager();
        pm.setComponentEnabledSetting(new ComponentName(context, MsgService.class),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
        pm.setComponentEnabledSetting(new ComponentName(context, MsgService.class),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
    }


    public static MsgCall msgCall=null;

    public static void setMsgCall(MsgCall msgCall) {
        MsgSrviceUtil.msgCall = msgCall;
    }

    public static MsgCall getMsgCall() {
        return msgCall;
    }

    public interface MsgCall{
        void newMsg(String text);
    }
}
