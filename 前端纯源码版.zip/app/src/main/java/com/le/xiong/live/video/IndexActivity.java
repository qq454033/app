package com.le.xiong.live.video;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.kproduce.roundcorners.RoundLinearLayout;
import com.kproduce.roundcorners.RoundTextView;
import com.le.xiong.live.video.util.MsgSrviceUtil;
import com.le.xiong.live.video.util.SystemUtils;

public class IndexActivity extends AppCompatActivity {

    private RoundLinearLayout perRW;
    private RoundLinearLayout perMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);

        perRW=findViewById(R.id.per_rw);
        perMsg=findViewById(R.id.per_msg);

        //全屏适配
        if (SystemUtils.isNavigationBarShow(this)){
            int h=SystemUtils.getNavigationBarHeight(this);
            LinearLayout box=findViewById(R.id.box);
            box.setPadding(0 ,0,0,h);
        }

        ImageView imageView=findViewById(R.id.index_image);
        imageView.setImageResource(R.mipmap.start);
        /*Glide.with(this)
                .load(ConfigUtil.getIndexImage(this))
                .into(imageView);*/
        //imageView.setImageResource(R.mipmap.start);

        /*try {
            imageView.setImageBitmap(BitmapFactory.decodeStream(getAssets().open("index.png")));
        } catch (IOException e) {
            e.printStackTrace();
        }*/

        requestPer();

        findViewById(R.id.per_re_rw).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPer();
            }
        });

        findViewById(R.id.per_re_msg).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MsgSrviceUtil.gotoNotificationAccessSetting(IndexActivity.this);
            }
        });
    }

    private void requestPer(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO},996);
        }
    }

    private boolean to=false;
    private void start(){
        final RoundTextView toMain=findViewById(R.id.to_main);
        @SuppressLint("HandlerLeak")
        final Handler handler=new Handler(){
            @SuppressLint("SetTextI18n")
            @Override
            public void handleMessage(@NonNull Message msg) {
                toMain.setText("跳过("+msg.what+")");
            }
        };
        toMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(IndexActivity.this,LoginActivity.class));
                to=true;
                finish();
            }
        });
        new Thread(new Runnable() {
            @Override
            public void run() {
                for(int i=3;i>0;i--){
                    if (to) break;
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Message message=new Message();
                    message.what=i-1;
                    handler.sendMessage(message);
                    if (i==1){
                        startActivity(new Intent(IndexActivity.this,LoginActivity.class));
                        finish();
                    }
                }

            }
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode==996){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED){
                    perRW.setVisibility(View.GONE);
                    if (!MsgSrviceUtil.isEnabled(this)){
                        perMsg.setVisibility(View.VISIBLE);
                    }else {
                        findViewById(R.id.index_bg).setVisibility(View.GONE);
                        start();
                    }
                }else {
                    perRW.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (MsgSrviceUtil.isEnabled(this)){
            perMsg.setVisibility(View.GONE);
            findViewById(R.id.index_bg).setVisibility(View.GONE);
            start();
        }
    }

}
