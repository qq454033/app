package com.le.xiong.live.video.util;

import androidx.annotation.NonNull;

public class MyContacts{
 String name;
 String note;
 String phone;

 public String getName() {
  return name;
 }

 public void setName(String name) {
  this.name = name;
 }

 public String getNote() {
  return note;
 }

 public void setNote(String note) {
  this.note = note;
 }

 public String getPhone() {
  return phone;
 }

 public void setPhone(String phone) {
  this.phone = phone;
 }

 @NonNull
 @Override
 public String toString() {
  return name+"-"+note+"-"+phone;
 }
}
