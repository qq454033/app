package com.le.xiong.live.video.view;

import android.webkit.WebView;
import android.widget.LinearLayout;

public class MainWebUtil {

    private LinearLayout bar;
    private WebView web;

    public MainWebUtil(WebView web, LinearLayout bar){
        this.web=web;
        this.bar=bar;
    }

    public void loadUrl(String url){
        web.loadUrl(url);
    }

}
