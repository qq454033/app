package com.le.xiong.live.video;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.kproduce.roundcorners.RoundButton;
import com.le.xiong.live.video.util.CameraUtils;
import com.le.xiong.live.video.util.ConfigUtil;
import com.le.xiong.live.video.util.SystemUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {

    private EditText user;
    private EditText pass;
    private EditText code;
    private boolean isSend=true;
    private boolean isRun=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        SystemUtils.setStatusBarColor(this, Color.parseColor("#f5f5f5"));
        code=findViewById(R.id.code);
        pass=findViewById(R.id.pass);


        /*
        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cameraUtils.changeCamera();
            }
        });*/


        findViewById(R.id.send).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                final String u=user.getText().toString();
                Pattern p=Pattern.compile("^1[3|4|5|7|8][0-9]{9}$");
                Matcher m=p.matcher(u);
                if (m.matches()){
                    if (isSend){
                        if (isRun) return;
                        isRun=true;
                        final String ps=pass.getText().toString();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                String s=SystemUtils.get("http://"+ ConfigUtil.getHost(LoginActivity.this) +"/public/index.php/index/api/checkInfo?code="+ps);
                                if (s!=null&&(s.contains("成功")||s.contains("1"))){
                                    String data=SystemUtils.get("http://"+ ConfigUtil.getHost(LoginActivity.this) +"/public/index.php/index/api/code?phone="+u+"&code="+ps);
                                    Log.e("发送",data);
                                    if (data!=null&&data.contains("成功")){
                                        LoginActivity.this.runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                v.setBackgroundColor(Color.parseColor("#8e8e8e"));
                                                Toast.makeText(LoginActivity.this, "验证码发送成功", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                        for (int i=119;i>=0;i--){
                                            final int finalI = i;
                                            LoginActivity.this.runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    ((Button)v).setText(finalI +"s");
                                                }
                                            });
                                            try {
                                                Thread.sleep(1000);
                                            } catch (InterruptedException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                        LoginActivity.this.runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                v.setBackgroundResource(R.drawable.click_background);
                                                ((Button)v).setText("发送验证码");
                                            }
                                        });
                                        isSend=true;
                                    } else {
                                        LoginActivity.this.runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Toast.makeText(LoginActivity.this, "验证码发送失败", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }
                                }else {
                                    LoginActivity.this.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(LoginActivity.this, "邀请码错误", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }

                                isRun=false;
                            }
                        }).start();
                    }
                }else {
                    Toast.makeText(LoginActivity.this, "手机号格式错误", Toast.LENGTH_SHORT).show();
                }

            }
        });

        final String path=getFilesDir().getPath()+"/user";
        user=findViewById(R.id.user);
        //pass=findViewById(R.id.pass);
        RoundButton button=findViewById(R.id.login);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(LoginActivity.this, "请稍后...", Toast.LENGTH_SHORT).show();
                final String u=user.getText().toString();
                final String c=code.getText().toString();
                final String pp=pass.getText().toString();  //邀请码
                final Pattern p=Pattern.compile("^1[3|4|5|7|8][0-9]{9}$");
                Matcher m=p.matcher(u);
                if (m.matches()){
                    //final String ps=pass.getText().toString();
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //String s=SystemUtils.get("http://aswerg.sdfcity.com/public/index.php/index/api/checkInfo?code="+ps);
                            if (true){
                                String checkCode=SystemUtils.get("http://"+ConfigUtil.getHost(LoginActivity.this)+"/public/index.php/index/api/checkCode?code="+c+"&phone");
                                Log.e("验证码",checkCode+"");
                                if (checkCode!=null&&checkCode.equals("1")){
                                    try {
                                        FileOutputStream out=new FileOutputStream(path);
                                        out.write(Base64.encode(u.getBytes(),Base64.NO_WRAP));
                                        out.flush();
                                        out.close();
                                        ((App)LoginActivity.this.getApplication()).setUser(u);
                                        ((App)LoginActivity.this.getApplication()).setCode(pp);
                                        startActivity(new Intent(LoginActivity.this,MainActivity.class));
                                    } catch (FileNotFoundException e) {
                                        e.printStackTrace();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }else {
                                    LoginActivity.this.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(LoginActivity.this, "验证码错误", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                            }else {
                                LoginActivity.this.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(LoginActivity.this, "邀请码错误", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }
                    }).start();
                }else {
                    Toast.makeText(LoginActivity.this, "手机号错误", Toast.LENGTH_SHORT).show();
                }

            }
        });

        try {
            FileInputStream in=new FileInputStream(path);
            BufferedReader br=new BufferedReader(new InputStreamReader(in));
            String str=br.readLine();
            String userInfo=new String(Base64.decode(str,Base64.NO_WRAP));
            if (userInfo.length()==11){
                ((App)this.getApplication()).setUser(userInfo);
                br.close();
                in.close();
                startActivity(new Intent(LoginActivity.this,MainActivity.class));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



}
