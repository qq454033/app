package com.le.xiong.live.video;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.le.xiong.live.video.util.AESUtils;
import com.le.xiong.live.video.util.PayUtil;
import com.le.xiong.live.video.util.SystemUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class PayTempActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout linearLayout=new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
        setContentView(linearLayout);

        PayUtil.showLoad(this);
        SystemUtils.setStatusBarColor(this, Color.WHITE);
        String URL;
        try {
            InputStream in=getAssets().open("config.txt");
            BufferedReader br=new BufferedReader(new InputStreamReader(in));
            String urlData=br.readLine();
            URL = AESUtils.AES_Decrypt(urlData,"xiaochenxiugai","CBC");
            if (URL==null){
                Toast.makeText(this, "支付失败", Toast.LENGTH_SHORT).show();
                finish();
            }else {
                PayUtil.init(PayTempActivity.this,linearLayout,null,URL);
            }
        } catch (IOException e) {
            e.printStackTrace();
            finish();
            Toast.makeText(this, "系统错误。", Toast.LENGTH_SHORT).show();
        }
    }
}
