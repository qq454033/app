package com.le.xiong.live.video;

import com.le.xiong.live.video.util.SystemUtils;

import org.junit.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        /*Pattern pattern=Pattern.compile(".*?([0-9]{6}).*?");
        Matcher matcher=pattern.matcher("你正在使用新设备支付518.00元，验证码431286，泄露验证码会影响资金安全。唯一热线：95188【支付宝】");
        if (matcher.find()) {
            String str = matcher.group(1);
            System.out.println(str);
        }*/
        /*String str="\\xxs";
        System.out.println(str);
        String sp=str.replaceAll("\\\\","");
        System.out.println(sp);*/
        //System.out.println(SystemUtils.get("http://aa.rsffz1.com/public/index.php/index/api/getInfo"));


        //System.out.println(m.matches());

    }
}